<header>
    <h1>
        TITRE
    </h1>
</header>