<footer>
    <h3>Footer</h3>
</footer>